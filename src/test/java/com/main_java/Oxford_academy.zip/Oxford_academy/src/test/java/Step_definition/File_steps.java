package Step_definition;

import Main.File_main;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class File_steps {
	File_main f = new File_main();
	@Given("^user launch chrome browser$")
	public void user_launch_chrome_browser() throws Throwable {
	    
	}

	@When("^user should open oxford website$")
	public void user_should_open_oxford_website() throws Throwable {
	  
	}

	@Then("^checkFile$")
	public void checkfile() throws Throwable {
	  
	}


}
