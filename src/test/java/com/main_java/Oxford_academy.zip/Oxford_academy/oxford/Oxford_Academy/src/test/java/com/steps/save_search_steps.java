package com.steps;

import com.main.save_search;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class save_search_steps
{
save_search save=new save_search();
@Given("The user launches the chrome browser")
public void the_user_launches_the_chrome_browser() throws Throwable {
	save.launch_browser() ;
}
@Then("user opens the website and logs in")
public void user_searches_a_journal_and_saves() throws Throwable {
	save.Oxford_homepage();

}

@Then("user searches a journal and saves")
public void user_checks_for_the_saved_search() throws Throwable {
	save.search_journal();
}

@Then("user checks for the saved search")
public void user_opens_the_saved_search() throws Throwable {
	save.check_saved_search();
}
@Then("user closes the browser")
public void user_closes_the_browser() throws Throwable {
	save.quit();
}


	
}
