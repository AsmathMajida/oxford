package com.steps;

import com.main.delete_saved_search;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class delete_saved_steps {
	delete_saved_search delete = new delete_saved_search();
	@Given("The user should launch the chrome browser")
	public void the_user_launches_the_chrome_browser() throws Throwable {
		delete.launch_browser();
	}
	@Then("user should open the website and logs in")
	public void user_searches_a_journal_and_saves() throws Throwable {
		delete. Oxford_homepage();

	}
	@Then("user should open the saved search")
	public void user_opens_the_saved_search() throws Throwable {
		delete.search_page();
	}

	@Then("user should delete the saved search")
	public void user_deletes_the_saved_search() throws Throwable {
		delete.delete_saved();
	}
	@Then("user should close the browser")
	public void user_closes_the_browser() throws Throwable {
		delete.quit();
	}
}
