package com.steps;

import com.main.change_password;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class change_password_steps {
	change_password password = new change_password();
	@Given("user launches the chrome browser")
	public void the_user_launches_the_chrome_browser() throws Throwable {
		password.launch_browser();
	}
	@When("The user opens the website and logs in")
	public void user_opens_the_website_and_logs_in() throws Throwable {
		password.Oxford_homepage();
	}


	@Then("The user opens the change password page")
	public void user_opens_the_change_password_page() throws Throwable {
		password.Change_password_page();
	}

	@Then("The user chnages the password")
	public void user_chnages_the_password() throws Throwable {
		password.edit_password();
	}
	@Then("The user closes the browser")
	public void user_closes_the_browser() throws Throwable {
		password.quit();
	}
}
