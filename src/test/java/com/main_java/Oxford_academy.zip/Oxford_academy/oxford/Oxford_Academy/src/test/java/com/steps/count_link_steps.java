package com.steps;

import com.main.count_link;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class count_link_steps {
	count_link count = new count_link();
	@Given("launch the chrome browser")
	public void the_user_launches_the_chrome_browser() throws Throwable {
		count.launch_browser(); 
	}
	@Then("open the website and logs in")
	public void user_searches_a_journal_and_saves() throws Throwable {
		count.Oxford_homepage();

	}
	@Then("count the number of journals and prints")
	public void user_counts_the_number_of_journals_and_prints() throws Throwable {
		count.count_link();
	}
	@Then("close the browser")
	public void user_closes_the_browser() throws Throwable {
		count.close();
	}

}
